package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Minimal bootstrapper compatible with the Gradle wrapper entry point.
 * It downloads the pinned official Gradle distribution and delegates the task.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (Exception e) {
            System.err.println("Gradle bootstrap failed: " + e.getMessage());
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    private static int run(String[] args) throws Exception {
        Path project = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path propsPath = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propsPath)) {
            throw new IOException("Missing gradle/wrapper/gradle-wrapper.properties in " + project);
        }
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(propsPath)) { properties.load(in); }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || !distributionUrl.startsWith("https://services.gradle.org/distributions/")) {
            throw new IOException("Only official services.gradle.org distributions are allowed");
        }
        String zipName = Paths.get(URI.create(distributionUrl).getPath()).getFileName().toString();
        String version = zipName.replace("gradle-", "").replace("-bin.zip", "").replace("-all.zip", "");
        String folderName = "gradle-" + version;
        Path cache = Paths.get(System.getProperty("user.home"), ".gradle", "wrapper", "dists", "bepar", folderName);
        Path gradleHome = cache.resolve(folderName);
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        Path executable = gradleHome.resolve("bin").resolve(windows ? "gradle.bat" : "gradle");

        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(cache);
            Path zip = cache.resolve(zipName);
            System.out.println("Downloading official Gradle " + version + " distribution...");
            URL url = URI.create(distributionUrl).toURL();
            try (InputStream in = url.openStream()) { Files.copy(in, zip, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
            String expected = properties.getProperty("distributionSha256Sum");
            if (expected != null && !expected.isBlank()) {
                String actual = sha256(zip);
                if (!actual.equalsIgnoreCase(expected.trim())) throw new IOException("Gradle distribution SHA-256 mismatch");
            }
            unzipSafely(zip, cache);
            Files.deleteIfExists(zip);
            if (!windows && Files.isRegularFile(executable)) executable.toFile().setExecutable(true, true);
        }
        if (!Files.isRegularFile(executable)) throw new IOException("Gradle executable was not found after extraction");

        List<String> command = new ArrayList<>();
        if (windows) { command.add("cmd.exe"); command.add("/c"); }
        command.add(executable.toString());
        for (String arg : args) command.add(arg);
        ProcessBuilder builder = new ProcessBuilder(command);
        builder.directory(project.toFile());
        builder.inheritIO();
        return builder.start().waitFor();
    }

    private static String sha256(Path file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buffer = new byte[1024 * 64];
            int n;
            while ((n = in.read(buffer)) >= 0) if (n > 0) digest.update(buffer, 0, n);
        }
        StringBuilder out = new StringBuilder();
        for (byte b : digest.digest()) out.append(String.format("%02x", b));
        return out.toString();
    }

    private static void unzipSafely(Path zip, Path destination) throws IOException {
        Path root = destination.toAbsolutePath().normalize();
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry entry;
            byte[] buffer = new byte[1024 * 64];
            while ((entry = in.getNextEntry()) != null) {
                Path target = root.resolve(entry.getName()).normalize();
                if (!target.startsWith(root)) throw new IOException("Unsafe path in Gradle distribution archive");
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    try (var out = Files.newOutputStream(target)) {
                        int n;
                        while ((n = in.read(buffer)) >= 0) if (n > 0) out.write(buffer, 0, n);
                    }
                }
                in.closeEntry();
            }
        }
    }
}
