# ──────────────────────────────────────────────────────────────────────────
# Bepar VPN — R8 / ProGuard rules
# Copyright © Bepar VPN. All rights reserved.
# This file controls code shrinking, obfuscation and optimization for the
# release build. Do not disable minification/obfuscation in release builds —
# doing so ships readable class/method names and makes static analysis and
# tampering trivially easy.
# ──────────────────────────────────────────────────────────────────────────

# Keep libbox JNI & gomobile bridge classes (required: called by name from native code)
-keep class io.nekohasekai.libbox.** { *; }
-keep class go.** { *; }
-dontwarn io.nekohasekai.libbox.**
-dontwarn go.**

# ── Obfuscation hardening ───────────────────────────────────────────────
# Flatten all obfuscated classes into one package instead of mirroring the
# original package tree — removes a major readability cue from decompiled
# output (jadx/apktool otherwise reconstruct com/bepar/vpn/... layout).
-repackageclasses 'a'
-flattenpackagehierarchy
-allowaccessmodification
-overloadaggressively
-mergeinterfacesaggressively

# Strip all logging + debug metadata from the release build. Source file
# names and line numbers are removed; stack traces still work (R8 still
# emits a mapping.txt you keep privately for your own crash symbolication).
-renamesourcefileattribute SourceFile
-keepattributes !LocalVariableTable,!LocalVariableTypeTable,!Exceptions
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# Keep Compose's runtime annotations and anything it reaches via reflection,
# but let R8 obfuscate/shrink everything else (default AndroidX compose
# consumer rules already cover most of this; these are extra safety nets).
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}

# NOTE: the app reads/writes its JSON (cache file, config URIs, diagnostics)
# with org.json using explicit string keys ("fetchedAtMs", "etag", ...),
# never via reflection on field names — so model/backend classes do NOT
# need a -keep rule and R8 is free to rename/repackage them too. If a
# reflection-based serializer (Gson/Moshi/kotlinx.serialization) is ever
# introduced, add a -keepclassmembers rule for exactly those classes then.

# Parcelable / instance-state creators (Android requires these names; no-op
# today since nothing implements Parcelable, kept as a safety net)
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}

# Don't warn on Kotlin metadata / coroutines internals pulled in transitively
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**
