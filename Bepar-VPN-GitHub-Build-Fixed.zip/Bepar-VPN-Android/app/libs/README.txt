libbox.aar — sing-box Android native core
============================================================

This binary is intentionally NOT stored in this repository because it is
larger than GitHub's browser upload limit. The GitHub Actions workflow downloads
the pinned upstream release before Gradle starts:

  https://github.com/singbox-android/libbox/releases/download/1.14.0/libbox.aar

The workflow checks the archive, required Java bridge classes, and the native
ARM64 library before compiling the app. Do not create an empty placeholder file.

Local build:
  mkdir -p app/libs
  curl -fL --retry 3 \
    https://github.com/singbox-android/libbox/releases/download/1.14.0/libbox.aar \
    -o app/libs/libbox.aar
  ./gradlew testDebugUnitTest assembleDebug

Architecture note:
  The libbox.aar bundled with this project snapshot contains
  jni/arm64-v8a/libbox.so. only. The generated APK is therefore intended for
  64-bit ARM Android devices. This archive does not provide 32-bit ARM or x86
  native libraries.
