package com.bepar.vpn

import com.bepar.vpn.backend.ConfigUriParser
import com.bepar.vpn.backend.GeoIpRepository
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.util.Base64

class ConfigUriParserAndDeduplicationTest {

    @Test
    fun parsesValidVlessTrojanVmessAndShadowsocks() {
        val vless = "vless://11111111-2222-3333-4444-555555555555@198.51.100.10:443?security=reality&sni=example.com&fp=chrome&pbk=abc123&sid=01#DE%20Node"
        val trojan = "trojan://secretpass@198.51.100.11:443?security=tls&sni=cdn.example.com&type=ws&path=/ws#NL%20Node"
        val ssUserInfo = Base64.getUrlEncoder().withoutPadding().encodeToString("aes-256-gcm:sspass".toByteArray())
        val ss = "ss://$ssUserInfo@198.51.100.12:8388#FI%20Node"

        val vmessJson = JSONObject().apply {
            put("v", "2")
            put("ps", "US Node")
            put("add", "198.51.100.13")
            put("port", "443")
            put("id", "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
            put("net", "ws")
            put("tls", "tls")
            put("sni", "us.example.com")
            put("path", "/vm")
        }.toString()
        val vmess = "vmess://" + Base64.getEncoder().encodeToString(vmessJson.toByteArray())

        val res = ConfigUriParser.parsePool(listOf(vless, trojan, ss, vmess))
        assertEquals(4, res.stats.valid)
        assertEquals(0, res.stats.invalid)
        assertEquals(0, res.stats.unsupported)
        assertEquals("reality", res.nodes[0].security)
        assertEquals("ws", res.nodes[1].network)
        assertEquals("aes-256-gcm", res.nodes[2].method)
        assertEquals("vmess", res.nodes[3].protocol)
    }

    @Test
    fun rejectsAllowInsecurePortZeroUnsupportedAndDeduplicates() {
        val valid = "vless://11111111-2222-3333-4444-555555555555@198.51.100.10:443?security=tls&sni=a.com#One"
        val dup = "vless://11111111-2222-3333-4444-555555555555@198.51.100.10:443?security=tls&sni=a.com#Copy"
        val insecure = "vless://11111111-2222-3333-4444-555555555555@198.51.100.20:443?security=tls&allowInsecure=1#Bad"
        val zeroPort = "trojan://pass@198.51.100.21:0?security=tls#Zero"
        val mkcp = "vless://11111111-2222-3333-4444-555555555555@198.51.100.22:443?type=kcp&seed=xyz#Kcp"
        val hy2 = "hysteria2://pass@198.51.100.23:443#Hy2"

        val res = ConfigUriParser.parsePool(listOf(valid, dup, insecure, zeroPort, mkcp, hy2))
        assertEquals(1, res.stats.valid)
        assertEquals(1, res.stats.duplicates)
        assertEquals(3, res.stats.invalid)
        assertEquals(1, res.stats.unsupported)
    }

    @Test
    fun decodesBase64SubscriptionAndCapsDiverseSample() {
        val lines = (1..30).map { i ->
            "vless://11111111-2222-3333-4444-555555555555@198.51.100.$i:443?security=tls&sni=h$i.example.com#Node$i"
        }
        val b64 = Base64.getEncoder().encodeToString(lines.joinToString("\n").toByteArray())
        val decoded = ConfigUriParser.decodeSubscriptionBody(b64)
        assertEquals(30, decoded.size)

        val parsed = ConfigUriParser.parsePool(decoded)
        assertEquals(30, parsed.nodes.size)
        val sampled = ConfigUriParser.selectDiverseSample(parsed.nodes, limit = 20)
        assertEquals(20, sampled.size)
        assertEquals(20, sampled.map { it.host }.distinct().size)
    }

    @Test
    fun geoIpConvertsIpv4IntegersCleanly() {
        assertEquals(0x01010101, GeoIpRepository.ipv4ToInt("1.1.1.1"))
        assertNull(GeoIpRepository.ipv4ToInt("999.1.1.1"))
        val (en, fa) = GeoIpRepository.countryNamesForCode("de")
        assertEquals("Germany", en)
        assertEquals("آلمان", fa)
    }
}
