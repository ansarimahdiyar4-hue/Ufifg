package com.bepar.vpn

import com.bepar.vpn.backend.SecurityGuard
import com.bepar.vpn.backend.SensitiveLogRedactor
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SecurityAndLogRedactionTest {

    @get:Rule
    val tmpFolder = TemporaryFolder()

    @Test
    fun redactsSensitiveProxyUrisAndCredentialsWhenEnabled() {
        val sample = "Connect failed for vless://uuid@example.com:443?pbk=secretPub&sid=aa password=myPass123"
        val redacted = SensitiveLogRedactor.redact(sample, enabled = true)
        assertFalse(redacted.contains("vless://"))
        assertFalse(redacted.contains("myPass123"))
        assertFalse(redacted.contains("secretPub"))
        assertTrue(redacted.contains("[redacted-config]"))

        val jsonSample = "{\"password\":\"topSecret99\",\"publicKey\":\"pub99\"}"
        val jsonRedacted = SensitiveLogRedactor.redact(jsonSample, enabled = true)
        assertFalse(jsonRedacted.contains("topSecret99"))
        assertFalse(jsonRedacted.contains("pub99"))

        val bypass = SensitiveLogRedactor.redact(sample, enabled = false)
        assertEquals(sample, bypass)
    }

    @Test
    fun integrityStoreDetectsFileTamperingAndHmacForgery() {
        val dir = tmpFolder.newFolder("integrity")
        val target = File(dir, "geoip_v4.bin.gz").apply { writeText("original-geoip-bytes") }
        val secret = "0123456789abcdef0123456789abcdef".toByteArray()

        val initial = SecurityGuard.verifyOrUpdateIntegrityStore(
            filesDir = dir,
            trackedFiles = listOf(target),
            hmacSecret = secret
        )
        assertTrue(initial.passed)
        assertTrue(File(dir, "integrity.json").exists())

        // Modify monitored file -> tamper detected
        target.writeText("tampered-geoip-bytes")
        val tampered = SecurityGuard.verifyOrUpdateIntegrityStore(
            filesDir = dir,
            trackedFiles = listOf(target),
            hmacSecret = secret
        )
        assertFalse(tampered.passed)
        assertEquals("geoip_v4.bin.gz", tampered.tamperFile)
    }
}
