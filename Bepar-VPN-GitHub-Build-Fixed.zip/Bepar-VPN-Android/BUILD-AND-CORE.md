# بیلد و اتصال — Bepar VPN Android

## وضعیت هسته

فایل `app/libs/libbox.aar` عمداً داخل مخزن قرار نمی‌گیرد؛ حجم آن از محدودیت آپلود وب GitHub بیشتر است. ورک‌فلو GitHub Actions نسخهٔ ثابت `1.14.0` را مستقیماً از Release رسمی `singbox-android/libbox` دانلود و قبل از کامپایل بررسی می‌کند.

## ساخت APK در GitHub

1. همهٔ فایل‌های این پروژه را در ریشهٔ Repository قرار دهید؛ پوشهٔ `.github/workflows` باید حفظ شود.
2. از تب **Actions**، ورک‌فلو **Build Bepar VPN APK** را اجرا کنید (یا روی شاخهٔ `main`/`master` یک commit ارسال کنید).
3. در اجرای موفق، از بخش **Artifacts** فایل `bepar-vpn-apk` را بگیرید.
4. ZIP را باز کنید و `app-debug.apk` را روی دستگاه نصب کنید.

ورک‌فلو ابتدا هستهٔ native را دانلود و اعتبارسنجی می‌کند، سپس تست‌های واحد و ساخت APK را اجرا می‌کند. اگر تست یا کامپایل شکست بخورد، Artifact منتشر نمی‌شود؛ خطای تست نادیده گرفته نمی‌شود.

## ساخت محلی

نیازمندی‌ها: JDK 17، Android SDK با `platforms;android-35` و Build Tools نسخهٔ `35.0.0`.

```bash
mkdir -p app/libs
curl -fL --retry 3 \
  https://github.com/singbox-android/libbox/releases/download/1.14.0/libbox.aar \
  -o app/libs/libbox.aar
./gradlew testDebugUnitTest assembleDebug
```

خروجی: `app/build/outputs/apk/debug/app-debug.apk`

## سازگاری معماری

AAR نسخهٔ 1.14.0 موجود در بستهٔ اولیه فقط کتابخانهٔ native برای `arm64-v8a` دارد. بنابراین APK حاصل برای دستگاه‌های اندرویدی ۶۴ بیتی ARM در نظر گرفته شده است؛ این فایل به‌تنهایی پشتیبانی ۳۲ بیتی ARM یا x86 را فراهم نمی‌کند.

## منبع هسته

https://github.com/singbox-android/libbox/releases/tag/1.14.0
