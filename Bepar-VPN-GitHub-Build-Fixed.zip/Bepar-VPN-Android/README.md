# Bepar VPN 2.0 — Android

Android client built with Kotlin, Jetpack Compose, Android `VpnService`, and sing-box `libbox` 1.14.0.

## Build APK

GitHub Actions downloads the pinned native `libbox.aar` release at build time (the binary is not committed because it exceeds GitHub's web-upload size limit), runs unit tests, builds the debug APK, verifies its signature, and uploads it as the `bepar-vpn-apk` artifact.

To build locally, see `BUILD-AND-CORE.md`.

## Native architecture

The libbox AAR used by this project snapshot contains `arm64-v8a` only. The generated APK is intended for 64-bit ARM Android devices.

Persian build instructions: `BUILD-AND-CORE.md`, `README_FA.md`.
