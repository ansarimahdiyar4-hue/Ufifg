# Bepar VPN 2.0 — پورت اندروید

پروژهٔ Android با Kotlin، Jetpack Compose، سرویس واقعی `VpnService` و هستهٔ sing-box (`libbox` نسخهٔ 1.14.0).

## بیلد APK

فایل native با حجم بالا داخل Repository قرار نمی‌گیرد. GitHub Actions هنگام Build نسخهٔ ثابت `libbox.aar` را از Release رسمی دانلود و اعتبارسنجی می‌کند، تست‌های واحد را اجرا می‌کند، APK دیباگ را می‌سازد و امضای آن را بررسی می‌کند. خروجی در Artifact با نام `bepar-vpn-apk` قرار می‌گیرد.

برای ساخت محلی، راهنمای `BUILD-AND-CORE.md` را ببینید.

## سازگاری

AAR هسته در این نسخه فقط `arm64-v8a` دارد؛ APK خروجی برای دستگاه‌های اندرویدی ۶۴ بیتی ARM است و این بسته پشتیبانی ۳۲ بیتی ARM یا x86 ندارد.
