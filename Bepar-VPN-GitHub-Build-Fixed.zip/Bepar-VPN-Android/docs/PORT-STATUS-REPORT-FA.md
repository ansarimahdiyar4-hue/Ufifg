# گزارش وضعیت پورت اندروید Bepar VPN 2.0 — نسخهٔ نهایی (با هسته)

تاریخ به‌روزرسانی: 2026-11-15

## وضعیت اتصال

| جزء | وضعیت |
|-----|--------|
| UI کامل | ✅ |
| VpnService + Manifest | ✅ |
| SourceRepository + فید زنده | ✅ (morpheus / iran.txt) |
| SingBoxConfigGenerator | ✅ |
| **libbox.aar v1.14.0** | ✅ **شامل شده** |
| تونل واقعی پس از بیلد+مجوز | ✅ مسیر کامل |

## ۱. بخش‌های کامل
- UI: خانه، سرورها، تنظیمات + انیمیشن + RTL + ۲۵۷ پرچم + فونت
- `BeparVpnService` یکپارچه با libbox (CommandServer/Client/PlatformInterface)
- فید پیش‌فرض زنده: morpheus (GitHub/jsDelivr، حدود ۳۰۰۰ کانفیگ)
- امنیت Keystore، کش رمزنگاری‌شده، تست پینگ، ranking و fallback

## ۲. برای اتصال واقعی روی گوشی
1. `./gradlew assembleDebug` (یا Build در Android Studio)
2. نصب APK
3. باز کردن اپ → پذیرش قوانین/آنبوردینگ
4. زدن Connect → اجازهٔ VPN سیستم را بدهید
5. هسته libbox تونل را بالا می‌آورد

اگر هسته در runtime لود نشود (نادر)، وضعیت `core_unavailable` نشان داده می‌شود.

## ۳. منبع هسته
`app/libs/libbox.aar` از:
https://github.com/singbox-android/libbox/releases/tag/1.14.0
