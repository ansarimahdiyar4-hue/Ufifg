# Source registry

## موارد قطعی

هفت ID زیر به ترتیب display positional در frontend ثبت شده‌اند:
1. `ss44` — Config Peer 1 / پیش‌فرض
2. `patterniha` — Config Peer 2
3. `anonymous` — Config Peer 3
4. `mahsa` — Config Peer 4
5. `radikal` — Config Peer 5
6. `morpheus` — Config Peer 6
7. `leon406` — Config Peer 7

UI عمداً نام واقعی feedها را مخفی می‌کند و نام ترتیبی Config Peer نشان می‌دهد.

## Description strings در EXE

این توضیحات در binary مشاهده شدند، اما نگاشت قطعی هر توضیح به ID از این strings به تنهایی ثابت نشده است:
- Source 1: Compatible with Irancell and Rightel
- Daily auto-crawled configs (ping-tested)
- Iran-focused bundle, mostly REALITY/Vision
- REALITY Public verified configs (Base64-encoded)
- Source 4: Compatible with Irancell, Hamrah-e Aval and fixed-line internet
- Source 3: Compatible with Irancell and Hamrah-e Aval
- Source 2: Compatible with Irancell

نام‌های واقعی در binary: Leon406, Morpheus, Adam Iran, 0xRadikal, Mahsa, Anonymous, Patterniha, SS44. به دلیل پنهان‌سازی در UI، نباید display labelها با نام backend/feed برابر دانسته شوند.

## Feed URLها

URLهای اصل subscription در archive حاضر پیدا نشدند. Endpoint محلی `http://127.0.0.1:9/SS44-gold.txt` فقط test fixture unreachable است.
