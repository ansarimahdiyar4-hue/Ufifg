# سرنخ‌های shape نوع‌های Rust از باینری

چند نام نوع و شمارنده field در رشته‌های type/serialization metadata مشاهده شده‌اند. شمارنده field به معنی بازیابی نام/نوع تک‌تک propertyها نیست:

| Type name | عناصر گزارش‌شده |
|---|---:|
| `VlessConfig` | 24 |
| `CacheEntry` | 12 |
| `TestCacheFile` | 1 |
| `CachedServer` | 20 |
| `SourceCache` | 9 |

نام‌های دیگری مانند `GeoResult`, `FeedStates`, `IntegrityBaseline`, `IntegrityStore`, `Settings`, `LastServer`, `Snapshot` نیز در رشته‌ها دیده شده‌اند، اما شمارنده/field map قابل اتکا برای همه آن‌ها بازیابی نشده است. این‌ها type-shape hints هستند، نه تعریف struct بازسازی‌شده.
