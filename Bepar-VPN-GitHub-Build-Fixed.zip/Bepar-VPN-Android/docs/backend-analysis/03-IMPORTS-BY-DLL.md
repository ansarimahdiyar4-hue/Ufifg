# Imported Windows DLLs and APIs (static import table)

DLL count: 29
Imported API count: 404

## advapi32.dll (11)
- EventRegister
- EventSetInformation
- EventUnregister
- EventWriteTransfer
- RegCloseKey
- RegDeleteValueW
- RegGetValueW
- RegOpenKeyExW
- RegQueryValueExW
- RegSetValueExW
- SystemFunction036

## api-ms-win-core-synch-l1-2-0.dll (3)
- WaitOnAddress
- WakeByAddressAll
- WakeByAddressSingle

## api-ms-win-core-winrt-error-l1-1-0.dll (1)
- RoOriginateErrorW

## api-ms-win-crt-convert-l1-1-0.dll (3)
- _ultow_s
- _wtoi
- wcstol

## api-ms-win-crt-heap-l1-1-0.dll (5)
- _callnewh
- _set_new_mode
- calloc
- free
- malloc

## api-ms-win-crt-locale-l1-1-0.dll (1)
- _configthreadlocale

## api-ms-win-crt-math-l1-1-0.dll (6)
- __setusermatherr
- floor
- pow
- round
- roundf
- trunc

## api-ms-win-crt-runtime-l1-1-0.dll (19)
- __p___argc
- __p___argv
- _c_exit
- _cexit
- _configure_narrow_argv
- _crt_atexit
- _exit
- _get_initial_narrow_environment
- _initialize_narrow_environment
- _initialize_onexit_table
- _initterm
- _initterm_e
- _register_onexit_function
- _register_thread_local_exe_atexit_callback
- _seh_filter_exe
- _set_app_type
- abort
- exit
- terminate

## api-ms-win-crt-stdio-l1-1-0.dll (2)
- __p__commode
- _set_fmode

## api-ms-win-crt-string-l1-1-0.dll (7)
- _wcsicmp
- strcmp
- strcpy_s
- strlen
- wcscmp
- wcslen
- wcsncmp

## bcrypt.dll (1)
- BCryptGenRandom

## bcryptprimitives.dll (1)
- ProcessPrng

## combase.dll (3)
- CoCreateFreeThreadedMarshaler
- CoTaskMemAlloc
- CoTaskMemFree

## comctl32.dll (4)
- DefSubclassProc
- RemoveWindowSubclass
- SetWindowSubclass
- TaskDialogIndirect

## crypt32.dll (2)
- CryptProtectData
- CryptUnprotectData

## dwmapi.dll (3)
- DwmEnableBlurBehindWindow
- DwmGetWindowAttribute
- DwmSetWindowAttribute

## gdi32.dll (13)
- BitBlt
- CombineRgn
- CreateCompatibleDC
- CreateDIBSection
- CreateRectRgn
- CreateSolidBrush
- DeleteDC
- DeleteObject
- GetDIBits
- GetDeviceCaps
- SelectObject
- SetBkMode
- SetTextColor

## imm32.dll (3)
- ImmGetCompositionStringW
- ImmGetContext
- ImmReleaseContext

## iphlpapi.dll (3)
- FreeMibTable
- GetIfEntry2
- GetIfTable2

## kernel32.dll (133)
- AcquireSRWLockExclusive
- AddVectoredExceptionHandler
- AssignProcessToJobObject
- AttachConsole
- CancelIoEx
- CheckRemoteDebuggerPresent
- CloseHandle
- CompareStringOrdinal
- CopyFileExW
- CreateDirectoryW
- CreateFileW
- CreateIoCompletionPort
- CreateJobObjectW
- CreateMutexA
- CreateMutexW
- CreateProcessW
- CreateThread
- CreateToolhelp32Snapshot
- CreateWaitableTimerExW
- DeleteCriticalSection
- DeleteFileW
- DuplicateHandle
- EncodePointer
- ExitProcess
- FindClose
- FindFirstFileExW
- FindNextFileW
- FlsAlloc
- FlsFree
- FlsSetValue
- FormatMessageW
- FreeEnvironmentStringsW
- FreeLibrary
- GetCommandLineW
- GetConsoleMode
- GetConsoleOutputCP
- GetCurrentDirectoryW
- GetCurrentProcess
- GetCurrentProcessId
- GetCurrentThread
- GetCurrentThreadId
- GetEnvironmentStringsW
- GetEnvironmentVariableW
- GetExitCodeProcess
- GetFileAttributesW
- GetFileInformationByHandle
- GetFileInformationByHandleEx
- GetFinalPathNameByHandleW
- GetFullPathNameW
- GetLastError
- GetModuleFileNameW
- GetModuleHandleA
- GetModuleHandleExW
- GetModuleHandleW
- GetOverlappedResult
- GetProcAddress
- GetProcessHeap
- GetProcessId
- GetQueuedCompletionStatusEx
- GetStdHandle
- GetSystemDirectoryW
- GetSystemInfo
- GetSystemTimeAsFileTime
- GetSystemTimePreciseAsFileTime
- GetTempPathW
- GetTimeZoneInformationForYear
- GetUserDefaultUILanguage
- GetWindowsDirectoryW
- HeapAlloc
- HeapFree
- HeapReAlloc
- InitializeCriticalSectionAndSpinCount
- InitializeSListHead
- IsDebuggerPresent
- IsProcessorFeaturePresent
- IsThreadAFiber
- LCIDToLocaleName
- LoadLibraryA
- LoadLibraryExA
- LoadLibraryExW
- LoadLibraryW
- LocalFree
- MoveFileExW
- MultiByteToWideChar
- OutputDebugStringA
- OutputDebugStringW
- PostQueuedCompletionStatus
- Process32FirstW
- Process32NextW
- QueryPerformanceCounter
- QueryPerformanceFrequency
- RaiseException
- ReadFile
- ReadFileEx
- RegisterWaitForSingleObject
- ReleaseMutex
- ReleaseSRWLockExclusive
- RtlCaptureContext
- RtlLookupFunctionEntry
- RtlPcToFileHeader
- RtlUnwindEx
- RtlVirtualUnwind
- SetEnvironmentVariableW
- SetFileCompletionNotificationModes
- SetFileInformationByHandle
- SetFilePointerEx
- SetFileTime
- SetHandleInformation
- SetInformationJobObject
- SetLastError
- SetStdHandle
- SetThreadStackGuarantee
- SetUnhandledExceptionFilter
- SetWaitableTimer
- Sleep
- SleepConditionVariableSRW
- SleepEx
- SwitchToThread
- TerminateProcess
- TlsAlloc
- TlsFree
- TlsGetValue
- TlsSetValue
- UnhandledExceptionFilter
- UnregisterWaitEx
- WaitForSingleObject
- WaitForSingleObjectEx
- WakeAllConditionVariable
- WideCharToMultiByte
- WriteConsoleW
- WriteFile
- WriteFileEx
- lstrlenW

## ntdll.dll (9)
- NtCancelIoFileEx
- NtCreateFile
- NtCreateNamedPipeFile
- NtDeviceIoControlFile
- NtOpenFile
- NtReadFile
- NtWriteFile
- RtlGetVersion
- RtlNtStatusToDosError

## ole32.dll (6)
- CoCreateInstance
- CoInitializeEx
- CoUninitialize
- OleInitialize
- RegisterDragDrop
- RevokeDragDrop

## oleaut32.dll (4)
- GetErrorInfo
- SetErrorInfo
- SysFreeString
- SysStringLen

## shell32.dll (10)
- DragFinish
- DragQueryFileW
- IsUserAnAdmin
- SHAppBarMessage
- SHGetKnownFolderPath
- SHGetStockIconInfo
- ShellExecuteExW
- ShellExecuteW
- Shell_NotifyIconGetRect
- Shell_NotifyIconW

## shlwapi.dll (1)
- SHCreateMemStream

## user32.dll (128)
- AdjustWindowRect
- AdjustWindowRectEx
- AllowSetForegroundWindow
- AppendMenuW
- ChangeDisplaySettingsExW
- ChangeWindowMessageFilterEx
- CheckMenuItem
- ClientToScreen
- ClipCursor
- CloseTouchInputHandle
- CreateAcceleratorTableW
- CreateIcon
- CreateMenu
- CreatePopupMenu
- CreateWindowExW
- DefWindowProcW
- DestroyAcceleratorTable
- DestroyIcon
- DestroyMenu
- DestroyWindow
- DispatchMessageA
- DispatchMessageW
- DrawIconEx
- DrawMenuBar
- DrawTextW
- EnableMenuItem
- EnableWindow
- EnumChildWindows
- EnumDisplayMonitors
- FillRect
- FindWindowExW
- FindWindowW
- FlashWindowEx
- GetActiveWindow
- GetAsyncKeyState
- GetClientRect
- GetClipCursor
- GetCursorPos
- GetDC
- GetForegroundWindow
- GetIconInfo
- GetKeyState
- GetKeyboardLayout
- GetKeyboardState
- GetMenu
- GetMenuBarInfo
- GetMenuItemInfoW
- GetMessageA
- GetMessageW
- GetMonitorInfoW
- GetParent
- GetRawInputData
- GetSystemMenu
- GetSystemMetrics
- GetTouchInputInfo
- GetUpdateRect
- GetWindow
- GetWindowDC
- GetWindowLongPtrW
- GetWindowLongW
- GetWindowPlacement
- GetWindowRect
- GetWindowTextLengthW
- GetWindowTextW
- GetWindowThreadProcessId
- InsertMenuW
- InvalidateRect
- InvalidateRgn
- IsIconic
- IsProcessDPIAware
- IsWindowEnabled
- IsWindowVisible
- KillTimer
- LoadCursorW
- LoadImageW
- MapVirtualKeyExW
- MapVirtualKeyW
- MapWindowPoints
- MonitorFromPoint
- MonitorFromRect
- MonitorFromWindow
- MsgWaitForMultipleObjectsEx
- OffsetRect
- PeekMessageW
- PostMessageW
- PostQuitMessage
- PostThreadMessageW
- RedrawWindow
- RegisterClassExW
- RegisterClassW
- RegisterRawInputDevices
- RegisterTouchWindow
- RegisterWindowMessageA
- ReleaseCapture
- ReleaseDC
- RemoveMenu
- ScreenToClient
- SendInput
- SendMessageW
- SetCapture
- SetCursor
- SetCursorPos
- SetFocus
- SetForegroundWindow
- SetMenu
- SetMenuItemInfoW
- SetParent
- SetPropW
- SetTimer
- SetWindowDisplayAffinity
- SetWindowLongPtrW
- SetWindowLongW
- SetWindowPlacement
- SetWindowPos
- SetWindowRgn
- SetWindowTextW
- ShowCursor
- ShowWindow
- SystemParametersInfoA
- SystemParametersInfoW
- ToUnicodeEx
- TrackMouseEvent
- TrackPopupMenu
- TranslateAcceleratorW
- TranslateMessage
- UpdateWindow
- ValidateRect
- VkKeyScanW

## wininet.dll (1)
- InternetSetOptionW

## wintrust.dll (1)
- WinVerifyTrust

## ws2_32.dll (20)
- WSAGetLastError
- WSAIoctl
- WSASend
- WSASocketW
- WSAStartup
- bind
- closesocket
- connect
- freeaddrinfo
- getaddrinfo
- getpeername
- getsockname
- getsockopt
- ioctlsocket
- listen
- recv
- select
- send
- setsockopt
- shutdown
