# موارد Backend که با فایل‌های فعلی حل نشدند

| مورد | چرا قابل استخراج قطعی نیست | فایل/داده لازم |
|---|---|---|
| متن کامل توابع Rust | EXE machine code است و source archive داخل ورودی نیست | Git repo یا `src-tauri/src/` |
| Cargo.toml / Cargo.lock | manifestها در ZIP نبودند | پروژه توسعه‌دهنده یا build cache |
| subscription URLهای 7 source | URL literal واقعی از dump استاتیک پیدا نشد؛ source IDs و descriptions دیده شدند | source.rs/registry، settings/cache runtime، یا source bundle |
| الگوریتم دقیق encryption/serialization | markerها و DPAPI imports پیدا شدند؛ envelope/nonce/tag/code path کامل نیست | `crypto.rs`, test vectors, connection-key.bin + matching code |
| کلید MAC و فرمول integrity | integrity store/MAC strings شناسایی شدند، محاسبات و key source نه | `security.rs`, integrity.json, original update/signing keys |
| دقیقاً چه شرطی هر stage را قبول می‌کند | شمارنده و label stageها هست؛ thresholds/weights numeric constants کامل recover نشده | pool.rs/tester.rs, logs, debugger trace |
| failover limit و ranking weights | وجود limit/rank-budget strings قطعی؛ مقدارها مشخص نیست | source + config/runtime logs |
| Xray JSON کامل و inbound/outbound tags exact | validation strings و stat keys هستند، full generated JSON ثابت یا runtime dump نیست | xraycfg.rs یا config dump هنگام اجرا |
| runtime source configs | هیچ کانفیگ واقعی در ZIP نبود | `configs.txt`, source cache, export از app |
| system proxy restore exact semantics | Windows registry imports/backup path/strings هستند؛ full transaction code نیست | sysproxy.rs + registry snapshot/logs |
| TLS interception host sequence و threshold exact | پیام دو host/HTTP available موجود است؛ تمام probe implementation نیست | intercept.rs |
| update signature verification details | signature/update verification fields strings دیده شدند؛ key/cert/verifier/manifest نبود | update source, public key, security.rs |

## نشانه‌های مهم برای بازیابی سورس واقعی

PE Debug Directory انتظار فایل `bepar_vpn.pdb` را ثبت کرده:
- GUID `cd2582cbd81e4e4883b161605cf6cea1`
- Age `1`
- نام: `bepar_vpn.pdb`

محل‌های احتمالی روی دستگاه build: `src-tauri/target/release/bepar_vpn.pdb`, `src-tauri/target/debug/bepar_vpn.pdb`, مسیر build artifact یا پوشه release. تنها PDB با GUID/Age یکسان برای این EXE معتبر است.

همچنین باینری مسیر build را به پوشه‌ای با انتهای `Videos\sors\src-tauri` اشاره می‌دهد. خود مسیر لوکال را نباید به عنوان source مطمئن فرض کرد، ولی می‌تواند سرنخ یافتن repo/backup باشد.
