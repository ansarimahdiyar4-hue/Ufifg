# Xray engine همراه Bepar VPN

## فایل همراه
- filename: `xray.exe`
- SHA-256: `15c2d007954ac53ba69b80ec91242786b3c0b71d52649165b4ca1d5cc96ef8f1`
- Go build info: `go1.26.1`, module `github.com/xtls/xray-core`, module version `(devel)`.
- `GOOS=windows`, `GOARCH=amd64`, `GOAMD64=v1`, `CGO_ENABLED=0`.
- این executable Windows PE، معماری x86-64 است. Android executable نیست.
- Go module version `(devel)` است؛ پس نباید به‌عنوان build رسمی/قابل اثبات `v26.3.27` معرفی شود. URL دانلود همان v26.3.27 در Bepar literal است، اما Go build info به‌تنهایی آن release را اثبات نمی‌کند.

SHA-256 باینری حاضر با hash pin مرتبط با Xray binary در رشته‌های Bepar برابر است؛ یعنی این فایل با hash مورد انتظار داخل Bepar تطابق دارد. این صرفاً تطابق integrity pin داخلی است و اصالت upstream امضاشده را به‌تنهایی ثابت نمی‌کند. رشته‌ای دیگر hash `d004c39288ce9ada487c6f398c7c545f7d749e44bdfdd59dbc9f865afba4e1ad` را نزدیک پیام‌های archive-hash mismatch و استخراج `xray.exe` ثبت کرده؛ این به احتمال زیاد pin آرشیو ZIP دانلودی است، اما چون ZIP منطبق در ورودی نیست، عملاً verify نشده است.

برای Wintun، hash `07c256185d6ee3652e09fa55c0b673e2624b565e02c4b9091c79ca7d2f24ef51` نزدیک مسیر `wintun/bin/amd64/wintun.dll` و پیام `wintun.dll extracted and hash-verified` است؛ به احتمال زیاد pin DLL است، نه لزوماً ZIP. این نیز در بسته ورودی قابل verify نبود.

## ساختار config/stats مشاهده‌شده
- config JSON دارای `inbounds`, `outbounds`, `routing`, `rules` و `stats`.
- `statsUserDownlink`, `statsInboundUplink`, `statsInboundDownlink`.
- پاسخ API stats با `stat[]` مورد انتظار است.
- inboundهای HTTP/SOCKS/TUN به‌صورت رشته/guard مشاهده شدند؛ exact config emitted file موجود نیست.

## وابستگی‌های Go

فایل `go-modules.json` همه `dep`های گزارش‌شده توسط `go version -m` را شامل می‌شود. گروه‌های فنی قابل مشاهده:
- QUIC: `apernet/quic-go`, `quic-go/qpack`
- TLS fingerprint / reality: `refraction-networking/utls`, `xtls/reality`, `cloudflare/circl`
- DNS: `miekg/dns`
- WireGuard/TUN: `golang.zx2c4.com/wireguard`, `golang.zx2c4.com/wintun`, `gvisor.dev/gvisor`
- transport/network: `gorilla/websocket`, `x/net`, `x/crypto`, `grpc`, `protobuf`
- compression/encoding: `klauspost/compress`, `andybalholm/brotli`, `yaml` modules.

توجه: این‌ها dependency build info از Xray executable هستند؛ لزوماً تمام features در Bepar config فعال نیستند.
